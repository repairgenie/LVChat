window.LVCHAT_CONFIG = {
  "serverUrl": "https://chat.lasvegasbestinternet.com",
  "appName": "LVChat Messenger",
  "shortName": "LVChat",
  "description": "IM-first client for LVChat — friends, direct messages and rooms.",
  "themeColor": "#26283c",
  "backgroundColor": "#1a1a24",
  "version": "1.0.0"
};
